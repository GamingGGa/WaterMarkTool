# WaterMarkTool
A little tool to add water mark on various pictures
